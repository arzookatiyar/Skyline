package Try;
import java.util.ArrayList;

class ArrayList_Try {

    public static void change_list(ArrayList list) {
	list.add("40");
    }
    
    public static void main(String args[]) {
	ArrayList a1 = new ArrayList();
	a1.add("1");
	a1.add("2");
	a1.add("3");
	a1.add("4");
	a1.add("5");
	a1.add("6");
	a1.add("7");
	a1.add(2, " 18");
	for (int i=0; i<a1.size(); i++) {
	    System.out.println(a1.get(i));
	}
	int len = a1.size();
	a1.add(len, "20");
	change_list(a1);

	System.out.println();
	for (int i=0; i<a1.size(); i++) {
	    System.out.println(a1.get(i));
	}
	
    }
}